public class Main {

    public static void main(String[] args) {

//        Question set 1
//        1a. Species is the child class of Genus , the relationship is an inheritance
//        2a. the relationship is a composition , since there is a use of instance of Species in the Specimen class
//        3a .          Specimen
//                  ----------------
//                   -name:String
//                   -cageNumber : int
//                   -toa : Species
//                  -----------------
//                  +Specimen(a:String,c:int,s:Species)
//                  +setname(a:String):void
//                  +setCage(c: int ): void
//                  +setToa(s:Species): void
//                  +getName():String
//                  +getCage():int
//                  +getSpecies():Species
//                  +toString(): String

//        4a. the inheritance method from the specimen and genus class , make the code more reusable , u dont need to
//        set one by one when creating a specimen class , it already has the instance and the method needed from the genus class
//        the second way would be the composition , as we know a species has a type of species , we make that type of species more detailed
//        in the species class , so when we need to add new instance , we can just add in there , rather than making it oneby one

//        5a. the Species class can stand alone without the  genus class , so it dont have any relationship , it still have their own method of toString
//        5aa. overwriting the defaul toString method

//        Question set 2
//        2a. protect your data from someone that you dont want to give access to
//        2b. protect an unwanted access by clients , reduce human error as its have a protective layer or validation
//        2c. setName, setCage,setToa,getName,getCage,getSpecies
//        2d. name,string ,toa
//        2e. public Genus(String similar ){this.similar =  similar} ##constructor
//        public void setSimilar(String a ){this.similar = a}##setter and getter
//        public String getSimilar(){return this.similar}
//        @override
//        public String toString(){return"Genus="+this.similar}
//        2f. advantage: you can inherit all the method that the super class have
//        disadvantage: it will become slower and use more memory cause when you make the speciemen it will also call the superclass


//        Question set 3
//        3a. make new instance called description in the species class
//        3b.
//        for(int i = 0 ;i<animal.size();i++){
//        if (animals[i].getToa.equals(s)){sum++}}
//        3c. Linkedlist<Specimen> listSpecies= new Linkedlist<Specimen>()
//            for(int i = 0 ;i<animal.size();i++){
//   if (!listSpecies.contains(animals[i].getToa){listSpecies.add (animals[i].getToa)}


//        Question set 4
//        4a. Dont have implementation and Have the same signature
//        4b. LinkedList makeList( Specimen[] animals )
//{
//        Linkedlist <Specimen> specimentList = new Linkedlist <Specimen>()
//        for(int i = 0 ;i<animal.size();i++){specimentList.add(animals[i])}
//        return specimenList
//}
//
//        4c LinkedList specialList( LinkedList animals)
////{
////        Linkedlist <Specimen> specialList = new Linkedlist <Species>()
////        for(int i = 0 ;i<animal.size();i++){
//          if !specialList.contain(animals.get(i).getToa)
//          {specialList.add(animals[i])}}
////        return specialList
////}

//        4d.
//        LinkedList specialUniqueList( LinkedList allanimals)
////{
////        Linkedlist <Specimen> specialUniqueList = new Linkedlist <Specimen>()
////        for(int i = 0 ;i<animal.size();i++){
//          if !specialList.contain(animals.get(i).getToa)
//          {specialUniqueList.add(animals[i])}}
////        return specialUniqueList
////}







    }
}
