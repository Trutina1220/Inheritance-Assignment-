public class Shape {
    private String color;
    private Boolean filled;

    public Shape(){
        this.color = "red";
        this.filled = true;
    }

    public Shape(String color, Boolean filled) {
        this.color = color;
        this.filled = filled;
    }



    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Boolean getFilled() {
        return filled;
    }

    public void setFilled(Boolean filled) {
        this.filled = filled;
    }

    public String getFilledString()
    {
        if(getFilled())
        {
            return "filled";
        }
        else{
            return "not filled";
        }
    }

    @Override
    public String toString() {
        return "A shape with color of "+this.color+" and "+getFilledString();
    }
}
