public class Main {

    public static void main(String[] args) {

        Shape s1 = new Shape("blue",true);
        System.out.println(s1.toString());

        Circle c1 = new Circle(2.5);
        System.out.println("Area="+c1.getArea()+",Perimeter="+c1.getPerimeter());
        System.out.println(c1.toString());

        Rectangle r1 = new Rectangle(4,6);
        System.out.println("Area="+r1.getArea()+",Perimeter="+r1.getPerimeter());
        System.out.println(r1.toString());

        Square sq1 = new Square();
        Square sq2 = new Square(5);
        System.out.println(sq1.toString());
        System.out.println("Area="+sq2.getArea()+",Perimeter="+sq2.getPerimeter());





    }
}
