public class Square extends Rectangle {

    public Square() {

    }

    public Square(double side)
    {
       super(side,side);
    }



    public Square(double side,String color, Boolean filled) {
        super(color, filled, side, side);
    }

    @Override
    public String toString() {
        return "A Square with side= "+getWidth()+", which is a subclass of "+super.toString();
    }

    @Override
    public void setWidth(double width) {
        super.setWidth(width);
        super.setLenght(width);
    }

    @Override
    public void setLenght(double lenght) {
        super.setLenght(lenght);
        super.setWidth(lenght);
    }
}
